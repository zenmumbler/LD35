Provided by Nobiax / Yughues


CC0 1.0 Universal (CC0 1.0)
Public Domain Dedication
No Copyright
This license is acceptable for Free Cultural Works
The person who associated a work with this deed has dedicated the work to the public domain by waiving all of his or her rights to the work worldwide under copyright law, including all related and neighboring rights, to the extent allowed by law.


You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.
Absolutely free to use or to modify in any kind of work (personal, commercial, educational or else)


Please, don't be an ass, don't do basic reselling of it
It's not the spirit and it's unfair to the author


Don't hesitate to share with me any glimpse of how you used it, on twitter: @Nobiax_Yughues

You can support me on Patreon: patreon.com/Yughues